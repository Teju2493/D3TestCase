const listYears = (data) => {
  const uniqueYears = {};
  // filter unique years
  const yearList = data.reduce((result, item) => {
    if (!uniqueYears[item.Year]) {
      uniqueYears[item.Year] = true;
      result.push(item.Year);
    }
    return result;
  }, []);

  // create list
  const select = document.getElementById("year-list");
  yearList.forEach(function (year) {
    var option = document.createElement("option");
    option.value = year;
    option.text = year;
    select.appendChild(option);
  });
};

const formatNumber = (number) => {
  if (number >= 1e12) {
    return (number / 1e12).toFixed(2) + " Tn";
  } else if (number >= 1e9) {
    return (number / 1e9).toFixed(2) + " Bn";
  } else {
    return number.toString();
  }
};

const renderScatterChart = (filteredData) => {
  // set the dimensions and margins of the graph
  const margin = { top: 10, right: 30, bottom: 40, left: 50 },
    // width = 620 - margin.left - margin.right,
    // height = 520 - margin.top - margin.bottom;
    width =
      document.getElementById("scatterplot").offsetWidth -
      margin.left -
      margin.right,
    height = 400;

  // append the svg object to the body of the page
  const svg = d3
    .select("#scatterplot")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  const tooltip = d3.select("#tooltips");

  // Determine the minimum and maximum values to calculate the radius
  var minValue = d3.min(filteredData, (d) =>
    parseInt(d["Population (000s)"].replace(",", ""))
  );
  var maxValue = d3.max(filteredData, (d) =>
    parseInt(d["Population (000s)"].replace(",", ""))
  );

  const uniqueCountry = {};
  const countryList = filteredData.reduce((result, item) => {
    if (!uniqueCountry[item.Country]) {
      uniqueCountry[item.Country] = true;
      result.push(item.Country);
    }
    return result;
  }, []);

  // calculate world population
  const worldPopulation = filteredData.reduce((accumulator, item) => {
    return accumulator + parseInt(item["Population (000s)"].replace(",", ""));
  }, 0);

  document.getElementById("population").innerHTML = formatNumber(
    worldPopulation * 1000
  );

  // Define the scale function to map data values to radii
  var radiusScale = d3
    .scaleLinear()
    .domain([minValue, maxValue])
    .range([5, 30]);

  // Add X axis
  var x = d3
    .scaleLinear()
    .domain([-10, d3.max(filteredData, (d) => d.Population_Density)])
    .range([0, width]);
  svg
    .append("g")
    .attr("transform", "translate(0," + height + ")")
    .call(d3.axisBottom(x));

  // Add Y axis
  var y = d3
    .scaleLinear()
    .domain([-5, d3.max(filteredData, (d) => d.Population_Growth_Rate)])
    .range([height, 0])
    .nice();
  svg.append("g").call(d3.axisLeft(y));

  // Add X axis label:
  svg
    .append("text")
    .attr("text-anchor", "end")
    .attr("x", width / 2 + margin.left)
    .attr("y", height + margin.top + 20)
    .text("Population Density");

  // Y axis label:
  svg
    .append("text")
    .attr("text-anchor", "end")
    .attr("transform", "rotate(-90)")
    .attr("y", -margin.left + 20)
    .attr("x", -margin.top - height / 2 + 20)
    .text("Population Growth Rate(%)");

  // Color scale: give me a specie name, I return a color
  var color = d3
    .scaleOrdinal()
    .domain(countryList) // Pass the list of countries as the domain
    .range(d3.schemeCategory10);

  // Add dots
  svg
    .append("g")
    .selectAll("dot")
    .data(filteredData)
    .enter()
    .append("circle")
    .attr("cx", function (d) {
      return x(d.Population_Density);
    })
    .attr("cy", function (d) {
      return y(d.Population_Growth_Rate);
    })
    .attr("r", function (d) {
      return radiusScale(parseInt(d["Population (000s)"].replace(",", "")));
    })
    .style("fill", function (d) {
      return color(d.Country);
    })
    .on("mouseover", function (d) {
      tooltip.style("display", "block");
      tooltip
        .html(
          `<strong>Country</strong>: ${d.Country}<br/><strong>Population</strong>: ${d["Population (000s)"]}<br/> `
        )
        .style("left", d3.event.pageX + 10 + "px")
        .style("top", d3.event.pageY - 30 + "px");
    })
    .on("mouseout", function () {
      tooltip.style("display", "none");
    });

  // create legends
  const legend = d3.select("#legend");

  var legendItems = legend
    .selectAll(".legend-item")
    .data(countryList)
    .enter()
    .append("label")
    .attr("class", "legend-item");

  legendItems
    .append("span")
    .attr("class", "legend-rect")
    .style("background-color", function (d) {
      return color(d);
    });

  // Add text labels to the legends
  legendItems
    .append("span")
    .attr("class", "legend-label")
    .text(function (d) {
      return d;
    });
};

const lineChart = (data) => {
  const populationByYear = {};
  data.forEach(function (item) {
    if (!populationByYear[item.Year]) {
      populationByYear[item.Year] = parseInt(
        item["Population (000s)"].replace(",", "")
      );
    } else {
      populationByYear[item.Year] += parseInt(
        item["Population (000s)"].replace(",", "")
      );
    }
  });

  var result = [];

  for (var key in populationByYear) {
    if (populationByYear.hasOwnProperty(key)) {
      result.push({ key: key, value: populationByYear[key] });
    }
  }

  // set the dimensions and margins of the graph
  var margin = { top: 10, right: 30, bottom: 30, left: 60 },
    // width = 460 - margin.left - margin.right,
    // height = 150 - margin.top - margin.bottom;
    width =
      document.getElementById("line-chart").offsetWidth -
      margin.left -
      margin.right,
    height = 100 - margin.top - margin.bottom;

  // append the svg object to the body of the page
  var svg = d3
    .select("#line-chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(0," + margin.top + ")");

  // Add X axis --> it is a date format
  var x = d3
    .scaleTime()
    .domain([new Date("1950"), new Date("2021")])
    .range([0, width]);
  svg
    .append("g")
    .attr("transform", "translate(0," + height + ")")
    .call(
      d3
        .axisBottom(x)
        .tickValues([new Date("1950"), new Date("2021")])
        .tickFormat(d3.timeFormat("%Y"))
    );

  // Add Y axis
  var y = d3
    .scaleLinear()
    .domain([
      0,
      d3.max(result, function (d) {
        return +d.value;
      }),
    ])
    .range([height, 0]);
  svg.append("g").call(d3.axisLeft(y)).remove();

  // Add the line
  svg
    .append("path")
    .datum(result)
    .attr("fill", "#ffc107")
    .attr("stroke", "#69b3a2")
    .attr("stroke-width", 1.5)
    .attr(
      "d",
      d3
        .area()
        .x(function (d) {
          return x(new Date(d.key));
        })
        .y0(y(0))
        .y1(function (d) {
          return y(d.value);
        })
    );

  // Display the first and last values on top of the area chart
  svg
    .append("text")
    .attr("x", x(new Date("1950")))
    .attr("y", y(result[0].value))
    .style("font-size", "8px")
    .text(formatNumber(result[0].value * 1000));

  svg
    .append("text")
    .attr("x", x(new Date(result[result.length - 5].key)))
    .attr("y", y(result[result.length - 1].value))
    .style("font-size", "10px")
    .text(formatNumber(result[result.length - 1].value * 1000));
};

const renderChart = (selectedYear = 1950, firstLoad) => {
  document.getElementById("scatterplot").innerHTML = "";
  document.getElementById("line-chart").innerHTML = "";

  //Read the data
  d3.csv("../data/population2.csv", function (data) {
    const filteredData = data.filter(function (d) {
      return d.Year == selectedYear;
    });

    listYears(data);
    // if (firstLoad)
    lineChart(data);
    renderScatterChart(filteredData);
  });
};

renderChart(1950, true);

const select = document.getElementById("year-list");
select.onchange = function () {
  var selectedOption = select.options[select.selectedIndex];
  var selectedYear = selectedOption.value;
  renderChart(selectedYear, false);
};

let resizeTimer;
window.addEventListener("resize", function () {
  clearTimeout(resizeTimer);

  resizeTimer = setTimeout(() => {
    var selectedOption = select.options[select.selectedIndex];
    var selectedYear = selectedOption.value;
    renderChart(selectedYear, true);
  }, 200);
});
